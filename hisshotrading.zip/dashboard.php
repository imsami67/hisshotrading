
<!doctype html>
<html lang="en">
  <?php include_once 'includes/head.php';  ?>
  <body class="vertical  dark  ">
    <div class="wrapper">
  <?php include_once 'includes/header.php'; ?>
   <?php include_once 'includes/sidebar.php'; ?>
      <main role="main" class="main-content">
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <?php include_once 'includes/footer.php'; ?>
  </body>
</html>