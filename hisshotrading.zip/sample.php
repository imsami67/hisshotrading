<?php include_once 'php_action/core.php'; 
  
?>
// <?php  if(!isset($_SESSION['userId'])){
//   header('location:login.php');
//   exit();
// } ?>

<!doctype html>
<html lang="en">
  <?php include_once 'includes/head.php'; ?>
  <body class="vertical  dark  ">
    <div class="wrapper">
  <?php include_once 'includes/header.php'; ?>
   <?php include_once 'includes/sidebar.php'; ?>
      <main role="main" class="main-content">
        

      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <?php include_once 'includes/foot.php'; ?>
  </body>
</html>